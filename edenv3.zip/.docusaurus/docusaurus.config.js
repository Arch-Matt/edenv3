export default {
  "title": "EDEN Network",
  "tagline": "EDEN",
  "url": "https://your-docusaurus-test-site.com",
  "baseUrl": "/",
  "onBrokenLinks": "throw",
  "onBrokenMarkdownLinks": "warn",
  "favicon": "img/favicon.ico",
  "organizationName": "EDEN",
  "projectName": "Website V3",
  "presets": [
    [
      "@docusaurus/preset-classic",
      {
        "docs": {
          "sidebarPath": "C:\\Users\\matt\\Documents\\EDEN\\Website_v3\\edenv3\\sidebars.js",
          "editUrl": "https://github.com/facebook/docusaurus/edit/main/website/"
        },
        "blog": {
          "showReadingTime": true,
          "editUrl": "https://github.com/facebook/docusaurus/edit/main/website/blog/"
        },
        "theme": {
          "customCss": [
            "C:\\Users\\matt\\Documents\\EDEN\\Website_v3\\edenv3\\src\\css\\m-grid.2.0.0.css",
            "C:\\Users\\matt\\Documents\\EDEN\\Website_v3\\edenv3\\src\\css\\slick.css",
            "C:\\Users\\matt\\Documents\\EDEN\\Website_v3\\edenv3\\src\\css\\slick-theme.css",
            "C:\\Users\\matt\\Documents\\EDEN\\Website_v3\\edenv3\\src\\css\\custom.css"
          ]
        }
      }
    ]
  ],
  "themeConfig": {
    "navbar": {
      "logo": {
        "alt": "EDEN Logo",
        "src": "img/eden-logo-white.svg"
      },
      "items": [
        {
          "type": "doc",
          "docId": "intro",
          "position": "left",
          "label": "Docs"
        },
        {
          "to": "/blog",
          "label": "Blog",
          "position": "left"
        },
        {
          "href": "https://google.co.uk",
          "label": "Launch App",
          "position": "right"
        }
      ],
      "hideOnScroll": false
    },
    "colorMode": {
      "disableSwitch": true,
      "defaultMode": "light",
      "respectPrefersColorScheme": false,
      "switchConfig": {
        "darkIcon": "🌜",
        "darkIconStyle": {},
        "lightIcon": "🌞",
        "lightIconStyle": {}
      }
    },
    "footer": {
      "style": "dark",
      "logo": {
        "src": "static/img/eden-logo-white.svg"
      },
      "links": [
        {
          "title": "Products",
          "items": [
            {
              "label": "Eden Relay",
              "to": "/docs/intro"
            },
            {
              "label": "Eden RPC",
              "to": "/docs/intro"
            },
            {
              "label": "EDEN Token",
              "to": "/docs/intro"
            },
            {
              "label": "yyAVAX on Yield Yak",
              "to": "/docs/intro"
            }
          ]
        },
        {
          "title": "Developers",
          "items": [
            {
              "label": "Github",
              "to": "/docs/intro"
            },
            {
              "label": "Docs",
              "to": "/docs/intro"
            }
          ]
        },
        {
          "title": "Company",
          "items": [
            {
              "label": "Eden Network",
              "to": "/docs/intro"
            },
            {
              "label": "Linkedin",
              "to": "/docs/intro"
            },
            {
              "label": "Brand Assets",
              "to": "/docs/intro"
            }
          ]
        },
        {
          "title": "Community",
          "items": [
            {
              "label": "Twitter",
              "to": "/docs/intro"
            },
            {
              "label": "Discord",
              "to": "/docs/intro"
            },
            {
              "label": "Medium",
              "to": "/docs/intro"
            },
            {
              "label": "Telegram",
              "to": "/docs/intro"
            }
          ]
        },
        {
          "title": "Legal",
          "items": [
            {
              "label": "Terms",
              "to": "/docs/intro"
            },
            {
              "label": "Privacy",
              "to": "/docs/intro"
            }
          ]
        }
      ],
      "copyright": "© Eden Network 2022."
    },
    "prism": {
      "theme": {
        "plain": {
          "color": "#F8F8F2",
          "backgroundColor": "#282A36"
        },
        "styles": [
          {
            "types": [
              "prolog",
              "constant",
              "builtin"
            ],
            "style": {
              "color": "rgb(189, 147, 249)"
            }
          },
          {
            "types": [
              "inserted",
              "function"
            ],
            "style": {
              "color": "rgb(80, 250, 123)"
            }
          },
          {
            "types": [
              "deleted"
            ],
            "style": {
              "color": "rgb(255, 85, 85)"
            }
          },
          {
            "types": [
              "changed"
            ],
            "style": {
              "color": "rgb(255, 184, 108)"
            }
          },
          {
            "types": [
              "punctuation",
              "symbol"
            ],
            "style": {
              "color": "rgb(248, 248, 242)"
            }
          },
          {
            "types": [
              "string",
              "char",
              "tag",
              "selector"
            ],
            "style": {
              "color": "rgb(255, 121, 198)"
            }
          },
          {
            "types": [
              "keyword",
              "variable"
            ],
            "style": {
              "color": "rgb(189, 147, 249)",
              "fontStyle": "italic"
            }
          },
          {
            "types": [
              "comment"
            ],
            "style": {
              "color": "rgb(98, 114, 164)"
            }
          },
          {
            "types": [
              "attr-name"
            ],
            "style": {
              "color": "rgb(241, 250, 140)"
            }
          }
        ]
      },
      "darkTheme": {
        "plain": {
          "color": "#F8F8F2",
          "backgroundColor": "#282A36"
        },
        "styles": [
          {
            "types": [
              "prolog",
              "constant",
              "builtin"
            ],
            "style": {
              "color": "rgb(189, 147, 249)"
            }
          },
          {
            "types": [
              "inserted",
              "function"
            ],
            "style": {
              "color": "rgb(80, 250, 123)"
            }
          },
          {
            "types": [
              "deleted"
            ],
            "style": {
              "color": "rgb(255, 85, 85)"
            }
          },
          {
            "types": [
              "changed"
            ],
            "style": {
              "color": "rgb(255, 184, 108)"
            }
          },
          {
            "types": [
              "punctuation",
              "symbol"
            ],
            "style": {
              "color": "rgb(248, 248, 242)"
            }
          },
          {
            "types": [
              "string",
              "char",
              "tag",
              "selector"
            ],
            "style": {
              "color": "rgb(255, 121, 198)"
            }
          },
          {
            "types": [
              "keyword",
              "variable"
            ],
            "style": {
              "color": "rgb(189, 147, 249)",
              "fontStyle": "italic"
            }
          },
          {
            "types": [
              "comment"
            ],
            "style": {
              "color": "rgb(98, 114, 164)"
            }
          },
          {
            "types": [
              "attr-name"
            ],
            "style": {
              "color": "rgb(241, 250, 140)"
            }
          }
        ]
      },
      "additionalLanguages": []
    },
    "docs": {
      "versionPersistence": "localStorage"
    },
    "metadatas": [],
    "hideableSidebar": false
  },
  "baseUrlIssueBanner": true,
  "i18n": {
    "defaultLocale": "en",
    "locales": [
      "en"
    ],
    "localeConfigs": {}
  },
  "onDuplicateRoutes": "warn",
  "customFields": {},
  "plugins": [],
  "themes": [],
  "titleDelimiter": "|",
  "noIndex": false
};