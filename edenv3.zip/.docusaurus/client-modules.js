export default [
  require("C:\\Users\\matt\\Documents\\EDEN\\Website_v3\\edenv3\\node_modules\\infima\\dist\\css\\default\\default.css"),
  require("C:\\Users\\matt\\Documents\\EDEN\\Website_v3\\edenv3\\node_modules\\@docusaurus\\theme-classic\\lib\\prism-include-languages"),
  require("C:\\Users\\matt\\Documents\\EDEN\\Website_v3\\edenv3\\node_modules\\@docusaurus\\theme-classic\\lib\\admonitions.css"),
  require("C:\\Users\\matt\\Documents\\EDEN\\Website_v3\\edenv3\\src\\css\\m-grid.2.0.0.css"),
  require("C:\\Users\\matt\\Documents\\EDEN\\Website_v3\\edenv3\\src\\css\\slick.css"),
  require("C:\\Users\\matt\\Documents\\EDEN\\Website_v3\\edenv3\\src\\css\\slick-theme.css"),
  require("C:\\Users\\matt\\Documents\\EDEN\\Website_v3\\edenv3\\src\\css\\custom.css"),
];
